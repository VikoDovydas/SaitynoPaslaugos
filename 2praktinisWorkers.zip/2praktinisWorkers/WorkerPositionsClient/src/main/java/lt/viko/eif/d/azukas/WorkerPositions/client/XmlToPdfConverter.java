package lt.viko.eif.d.azukas.WorkerPositions.client;

import org.apache.fop.apps.FOPException;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;
import org.xml.sax.SAXException;

import javax.xml.transform.*;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.*;

public class XmlToPdfConverter {

    public void convertToPdf(String xmlContent, String xslContent, String outputPdfPath) throws IOException, FOPException, TransformerException, SAXException {
        // Setup FOP
        FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());
        FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
        OutputStream out = new BufferedOutputStream(new FileOutputStream(new File(outputPdfPath)));

        try {
            // Construct FOP with desired output format
            org.apache.fop.apps.Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, out);

            // Setup XSLT
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer(new StreamSource(new StringReader(xslContent)));

            // Setup input for transformation
            Source src = new StreamSource(new StringReader(xmlContent));

            // Resulting SAX events (the generated FO) must be piped through to FOP
            Result res = new SAXResult(fop.getDefaultHandler());

            // Start the transformation and rendering process
            transformer.transform(src, res);
        } finally {
            out.close();
        }
    }
}
