package lt.viko.eif.d.azukas.WorkerPositions.client;

import org.apache.fop.apps.FOPException;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {
        String xmlUrl = "http://localhost:8080/xml/workers";
        String xslUrl = "http://localhost:8080/xml/WorkersToPdf.xsl";
        String outputPdfPath = "workers.pdf";

        try {
            // Fetch XML and XSL content
            String xmlContent = HttpClientUtil.fetchContent(xmlUrl);
            String xslContent = HttpClientUtil.fetchContent(xslUrl);

            // Convert XML to PDF
            XmlToPdfConverter converter = new XmlToPdfConverter();
            converter.convertToPdf(xmlContent, xslContent, outputPdfPath);

            System.out.println("PDF generated successfully at " + outputPdfPath);
        } catch (IOException | TransformerException | SAXException e) {
            e.printStackTrace();
        }
    }
}
