package lt.viko.eif.d.azukas.WorkerPositions.controller;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.nio.file.Files;

@RestController
public class WorkerController {

    @GetMapping("/xml/workers")
    public ResponseEntity<byte[]> getWorkersXml() throws IOException {
        Resource xmlFile = new ClassPathResource("WorkersList.xml");
        byte[] content = Files.readAllBytes(xmlFile.getFile().toPath());
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_XML);
        return ResponseEntity.ok().headers(headers).body(content);
    }

    @GetMapping("/xml/WorkersToPdf.xsl")
    public ResponseEntity<byte[]> getWorkersToPdfXsl() throws IOException {
        Resource xslFile = new ClassPathResource("WorkersToPdf.xsl");
        byte[] content = Files.readAllBytes(xslFile.getFile().toPath());
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_XML);
        return ResponseEntity.ok().headers(headers).body(content);
    }
}
