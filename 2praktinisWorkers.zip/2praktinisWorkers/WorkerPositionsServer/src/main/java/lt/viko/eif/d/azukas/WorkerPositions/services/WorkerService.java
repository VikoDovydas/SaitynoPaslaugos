package lt.viko.eif.d.azukas.WorkerPositions.services;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public interface WorkerService {
    @WebMethod
    <WorkersList>
    WorkersList getWorkers();
}
