package lt.viko.eif.d.azukas.WorkerPositions.services;

import lt.viko.eif.d.azukas.WorkerPositions.Util.XmlParser;
import lt.viko.eif.d.azukas.WorkerPositions.model.WorkersList;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import javax.jws.WebService;
import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service
@WebService(endpointInterface = "lt.viko.eif.d.azukas.WorkerPositions.services.WorkerService")
public class WorkerServiceImpl implements WorkerService {

    private static final Logger logger = Logger.getLogger(WorkerServiceImpl.class.getName());

    @Override
    public WorkersList getWorkers() {
        try {
            ClassPathResource resource = new ClassPathResource("WorkersList.xml");
            return XmlParser.parseWorkersList(resource.getFile().getPath());
        } catch (JAXBException | IOException e) {
            logger.log(Level.SEVERE, "Error parsing XML file", e);
            return new WorkersList(); // return an empty list in case of error
        }
    }
}
