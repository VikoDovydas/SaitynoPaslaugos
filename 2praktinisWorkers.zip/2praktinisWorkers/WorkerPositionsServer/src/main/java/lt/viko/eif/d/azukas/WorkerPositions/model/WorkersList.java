package lt.viko.eif.d.azukas.WorkerPositions.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "workers")
public class WorkersList {
    private List<Worker> workers;

    @XmlElement(name = "worker")
    public List<Worker> getWorkers() {
        return workers;
    }

    public void setWorkers(List<Worker> workers) {
        this.workers = workers;
    }
}
