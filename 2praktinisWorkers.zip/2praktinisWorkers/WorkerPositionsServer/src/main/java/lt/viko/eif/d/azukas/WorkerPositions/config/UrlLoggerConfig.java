package lt.viko.eif.d.azukas.WorkerPositions.config;

import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class UrlLoggerConfig {

    @Bean
    public ApplicationRunner logUrls() {
        return args -> {
            System.out.println("The application has started. Available URLs:");
            System.out.println("SOAP Web Service WSDL: http://localhost:8080/services/workers?wsdl");
            System.out.println("XML File Endpoint: http://localhost:8080/xml/workers");
            System.out.println("XSL File Endpoint: http://localhost:8080/xml/WorkersToPdf.xsl");
        };
    }
}
