package lt.viko.eif.d.azukas.WorkerPositions.config;

import lt.viko.eif.d.azukas.WorkerPositions.services.WorkerServiceImpl;
import org.apache.cxf.Bus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.xml.ws.Endpoint;

@Configuration
public class CxfConfig {

    private final Bus bus;
    private final WorkerServiceImpl workerServiceImpl;

    public CxfConfig(Bus bus, WorkerServiceImpl workerServiceImpl) {
        this.bus = bus;
        this.workerServiceImpl = workerServiceImpl;
    }

    @Bean
    public Endpoint endpoint() {
        EndpointImpl endpoint = new EndpointImpl(bus, workerServiceImpl);
        endpoint.publish("/workers");
        return endpoint;
    }
}
