package lt.viko.eif.d.azukas.WorkerPositions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkerServicePublisher {

    public static void main(String[] args) {
        SpringApplication.run(WorkerServicePublisher.class, args);
    }
}
