package lt.viko.eif.d.azukas;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.List;

@Path("/workers")
public class WorkerService {
    private static List<Worker> workerList = new ArrayList<>();

    static {
        workerList.add(new Worker(1, "John Doe", new Position("Developer", "IT")));
        workerList.add(new Worker(2, "Jane Smith", new Position("Manager", "HR")));
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Worker> getWorkers() {
        return workerList;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Worker getWorkerById(@PathParam("id") int id) {
        return workerList.stream()
                .filter(worker -> worker.getId() == id)
                .findFirst()
                .orElse(null);
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Worker addWorker(Worker worker) {
        workerList.add(worker);
        return worker;
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Worker updateWorker(@PathParam("id") int id, Worker updatedWorker) {
        for (Worker worker : workerList) {
            if (worker.getId() == id) {
                worker.setName(updatedWorker.getName());
                worker.setPosition(updatedWorker.getPosition());
                return worker;
            }
        }
        return null;
    }

    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Worker deleteWorker(@PathParam("id") int id) {
        Worker worker = workerList.stream()
                .filter(w -> w.getId() == id)
                .findFirst()
                .orElse(null);
        if (worker != null) {
            workerList.remove(worker);
        }
        return worker;
    }
}
