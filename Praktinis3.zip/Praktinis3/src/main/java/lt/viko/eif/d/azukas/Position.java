package lt.viko.eif.d.azukas;

public class Position {
    private String title;
    private String department;

    // Constructors, getters, and setters
    public Position() {}

    public Position(String title, String department) {
        this.title = title;
        this.department = department;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}
